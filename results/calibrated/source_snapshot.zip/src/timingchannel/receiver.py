"""Probing receiver: sample /ping latency and save the raw trace."""

from __future__ import annotations

import argparse
import math
import os
import signal
import threading
import time
from pathlib import Path

from timingchannel.codec import Sample, read_frame
from timingchannel.config import ChannelConfig
from timingchannel.wire import ping_once, utc_now_iso, wait_for_resource, write_json_atomic


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Sample latency of the shared resource")
    parser.add_argument(
        "--duration", type=float, default=float(os.environ.get("CHANNEL_DURATION_S", "30"))
    )
    parser.add_argument(
        "--output", default=os.environ.get("CHANNEL_RECEIVER_OUTPUT", "/run/channel/receiver.json")
    )
    parser.add_argument("--startup-timeout", type=float, default=30.0)
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    config = ChannelConfig.from_env()
    if not math.isfinite(args.duration) or args.duration < 0:
        raise ValueError("duration must be finite and nonnegative (0 means until stopped)")
    forbidden = {"CHANNEL_MESSAGE", "CHANNEL_BITS"}.intersection(os.environ)
    if forbidden:
        raise ValueError(f"receiver must not receive payload variables: {sorted(forbidden)}")
    wait_for_resource(config.host, config.port, args.startup_timeout)

    stop = threading.Event()

    def request_stop(signum: int, frame: object) -> None:
        stop.set()

    signal.signal(signal.SIGTERM, request_stop)
    signal.signal(signal.SIGINT, request_stop)

    start = time.monotonic()
    started_at = utc_now_iso()
    samples: list[Sample] = []
    next_sample = start

    print(
        f"receiver sampling: {config.host}:{config.port} "
        f"for {args.duration:.1f}s every {config.poll_ms:.1f}ms",
        flush=True,
    )
    # Private health marker: never mounted into another role.
    ready_path = Path(os.environ.get("CHANNEL_READY_FILE", "/tmp/receiver-ready"))
    ready_path.touch()

    while not stop.is_set():
        now = time.monotonic()
        elapsed = now - start
        if args.duration and elapsed >= args.duration:
            break

        if next_sample > now:
            time.sleep(min(next_sample - now, 0.05))

        sampled_at = time.monotonic()
        rtt_ms, timed_out = ping_once(config.host, config.port, config.timeout_s)
        samples.append(
            Sample(
                t_ms=round((sampled_at - start) * 1000.0, 3),
                rtt_ms=round(rtt_ms, 3),
                timeout=timed_out,
            )
        )

        next_sample += config.interval_s
        if next_sample < time.monotonic() - config.interval_s:
            next_sample = time.monotonic()

    decoded = read_frame(samples, config)
    capture = {
        "version": 2,
        "role": "receiver",
        "started_at": started_at,
        "duration_s": args.duration,
        "config": config.as_dict(),
        "decoded_bits": list(decoded.bits),
        "decode_error": decoded.error,
        "bit_threshold_ms": decoded.bit_threshold_ms,
        "samples": [
            {"t_ms": sample.t_ms, "rtt_ms": sample.rtt_ms, "timeout": sample.timeout}
            for sample in samples
        ],
    }
    write_json_atomic(args.output, capture)
    ready_path.unlink(missing_ok=True)

    rtts = [sample.rtt_ms for sample in samples if not sample.timeout]
    events = [rtt for rtt in rtts if rtt >= config.event_threshold_ms]
    print(
        f"receiver done: {len(samples)} samples, {len(events)} events, "
        f"max_rtt={max(rtts, default=0.0):.1f}ms -> {args.output}",
        flush=True,
    )


if __name__ == "__main__":
    main()
